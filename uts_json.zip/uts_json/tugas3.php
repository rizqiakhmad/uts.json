<?php
include "header.php";
?>

<?php

	$json_string1 = file_get_contents("http://api.wunderground.com/api/003d598e9401bd84/conditions/q/IA/mugas.json");
	$json_string2 = file_get_contents("http://api.wunderground.com/api/003d598e9401bd84/astronomy/q/IA/mugas.json");
	
	$parsed_json1 = json_decode ($json_string1);
	$parsed_json2 = json_decode ($json_string2);
	
	$tempat = $parsed_json1->{'current_observation'}->{'display_location'}->{'full'};
	$terbit1 = $parsed_json2->{'moon_phase'}->{'sunrise'}->{'hour'};
	$terbit2 = $parsed_json2->{'moon_phase'}->{'sunrise'}->{'minute'};
	$suhu = $parsed_json1->{'current_observation'}->{'temp_c'};
	$angin = $parsed_json1->{'current_observation'}->{'wind_mph'};
	$tanggal = $parsed_json1->{'current_observation'}->{'local_time_rfc822'};
	$terbenam1 = $parsed_json2->{'moon_phase'}->{'sunset'}->{'hour'};
	$terbenam2 = $parsed_json2->{'moon_phase'}->{'sunrise'}->{'minute'};
	
	echo "Cuaca saat ini di ${tempat}<br>
	${tanggal}";
	
	echo "<br>";
	echo "Suhu : ${suhu} <sup> o </sup>C";
	
	echo "<br>";
	
	echo "Kecepatan Angin : ${angin} meter/jam";
	echo "<br>";
	echo "Matahari Terbit pada Pukul ${terbit1}:${terbit1}\n";
	echo "<br>";
	echo "Matahari Terbenam pada Pukul ${terbenam1}:${terbenam2}\n";
	echo "<br>";
?>

</body>
</html>
